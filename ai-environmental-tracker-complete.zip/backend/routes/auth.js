import express from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import User from '../models/User.js';
import nodemailer from 'nodemailer';
const router = express.Router();

router.post('/register', async (req,res)=>{
  try{
    const { name,email,password } = req.body;
    if(!email||!password) return res.status(400).json({ message: 'Missing fields' });
    const exists = await User.findOne({ email });
    if(exists) return res.status(400).json({ message: 'User exists' });
    const user = await User.create({ name, email, password });
    res.json({ message: 'Registered' });
  }catch(e){ res.status(500).json({ message: e.message }) }
});

router.post('/login', async (req,res)=>{
  try{
    const { email,password } = req.body;
    const user = await User.findOne({ email });
    if(!user) return res.status(400).json({ message: 'Invalid credentials' });
    const ok = await user.matchPassword(password);
    if(!ok) return res.status(400).json({ message: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id, name: user.name, isAdmin: user.isAdmin }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '7d' });
    res.json({ token, user: { id: user._id, name: user.name, email: user.email, isAdmin: user.isAdmin } });
  }catch(e){ res.status(500).json({ message: e.message }) }
});

router.post('/forgot', async (req,res)=>{
  try{
    const { email } = req.body;
    const user = await User.findOne({ email });
    if(!user) return res.status(400).json({ message: 'No user' });
    const token = crypto.randomBytes(20).toString('hex');
    user.resetToken = token;
    user.resetTokenExp = Date.now() + 1000*60*60;
    await user.save();
    if(process.env.SMTP_HOST){
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: Number(process.env.SMTP_PORT) || 587,
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
      });
      const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/reset-password?token=${token}`;
      await transporter.sendMail({ from: process.env.SMTP_USER, to: user.email, subject: 'Password reset', text: `Reset link: ${resetUrl}` });
      return res.json({ message: 'Email sent' });
    } else {
      return res.json({ message: 'SMTP not configured - demo token', token });
    }
  }catch(e){ res.status(500).json({ message: e.message }) }
});

router.post('/reset', async (req,res)=>{
  try{
    const { token, password } = req.body;
    const user = await User.findOne({ resetToken: token, resetTokenExp: { $gt: Date.now() } });
    if(!user) return res.status(400).json({ message: 'Invalid or expired token' });
    user.password = password;
    user.resetToken = undefined;
    user.resetTokenExp = undefined;
    await user.save();
    res.json({ message: 'Password reset' });
  }catch(e){ res.status(500).json({ message: e.message }) }
});

export default router;
