import express from 'express';
import auth from '../middleware/auth.js';
import Activity from '../models/Activity.js';
import { analyzeActivity } from '../services/aiService.js';
const router = express.Router();

router.get('/', auth, async (req,res)=>{
  const list = await Activity.find({ userId: req.user.id }).sort({ date:-1 });
  res.json(list);
});

router.post('/', auth, async (req,res)=>{
  const { name, category, carbon } = req.body;
  const analysis = await analyzeActivity(name, category);
  const act = await Activity.create({ userId: req.user.id, name, category, carbon, aiAnalysis: analysis });
  res.json(act);
});

export default router;
