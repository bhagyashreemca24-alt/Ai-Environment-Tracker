import express from 'express';
import auth from '../middleware/auth.js';
import User from '../models/User.js';
import Activity from '../models/Activity.js';
const router = express.Router();
const isAdmin = async (req,res,next)=>{
  if(!req.user) return res.status(401).json({ message:'No token' });
  const u = await User.findById(req.user.id);
  if(!u || !u.isAdmin) return res.status(403).json({ message:'Admin only' });
  next();
};
router.get('/users', auth, isAdmin, async (req,res)=>{ const users = await User.find().select('-password -resetToken -resetTokenExp'); res.json(users); });
router.get('/activities', auth, isAdmin, async (req,res)=>{ const acts = await Activity.find().sort({ date:-1 }); res.json(acts); });
export default router;
