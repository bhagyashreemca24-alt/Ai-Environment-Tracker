import express from 'express';
import User from '../models/User.js';
import Activity from '../models/Activity.js';
import bcrypt from 'bcryptjs';
const router = express.Router();
router.post('/', async (req,res)=>{
  await User.deleteMany({});
  await Activity.deleteMany({});
  const pass = await bcrypt.hash('password',10);
  const demo = await User.create({ name:'Demo', email:'demo@example.com', password: pass, isAdmin: true });
  await Activity.create([
    { userId: demo._id.toString(), name:'Public transport', category:'Commuting', carbon:3, aiAnalysis:'Good choice' },
    { userId: demo._id.toString(), name:'Vegan meal', category:'Food', carbon:1, aiAnalysis:'Low impact' },
    { userId: demo._id.toString(), name:'Short flight', category:'Travel', carbon:120, aiAnalysis:'High impact' }
  ]);
  res.json({ message:'Seeded', demo:{ email: demo.email, password: 'password' } });
});
export default router;
