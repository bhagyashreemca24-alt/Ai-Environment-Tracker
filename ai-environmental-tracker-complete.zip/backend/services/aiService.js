import OpenAI from 'openai';
const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

export async function analyzeActivity(name, category){
  if(!client) return `Quick tip: ${name} (${category}) — consider lower-impact options.`;
  const prompt = `Analyze the environmental impact of "${name}" in category ${category}. Provide a short summary and one tip.`;
  const resp = await client.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{ role:'user', content: prompt }]
  });
  return resp.choices?.[0]?.message?.content || 'No analysis';
}
