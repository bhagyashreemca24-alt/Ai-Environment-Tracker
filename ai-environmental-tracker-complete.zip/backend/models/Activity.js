import mongoose from 'mongoose';
const schema = new mongoose.Schema({
  userId: String,
  name: String,
  category: String,
  carbon: Number,
  aiAnalysis: String,
  date: { type: Date, default: Date.now }
});
export default mongoose.model('Activity', schema);
