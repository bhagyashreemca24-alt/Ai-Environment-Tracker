# AI Environmental Tracker — Complete Project

This archive contains a full final-year project: React frontend + Node/Express backend + MongoDB + optional OpenAI integration.

## Quick start (local)

1) Backend

```
cd backend
cp .env.example .env
# edit .env (MONGO_URI, JWT_SECRET, OPENAI_API_KEY, SMTP settings)
npm install
npm run dev
```

2) Seed demo data

```
curl -X POST http://localhost:5000/api/seed
```

3) Frontend

```
cd frontend
npm install
npm run dev
# open http://localhost:5173
```

## MongoDB Atlas
1. Create an account at MongoDB Atlas and make a free cluster.
2. Create DB user & password.
3. Add your IP to Network Access or allow access from anywhere for dev.
4. Use the connection string as MONGO_URI in backend/.env (replace <user> and <pass>).

## Features
- Login/Register with validation
- Forgot password (token + email via SMTP; demo returns token)
- Protected Dashboard + Add Activity
- AI analysis (OpenAI) fallback if no key present
- Admin endpoints to list users & activities
- Responsive UI with animations

