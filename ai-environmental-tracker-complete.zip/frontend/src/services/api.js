import axios from 'axios'
const API = axios.create({ baseURL: 'http://localhost:5000/api' })
API.interceptors.request.use(cfg=>{ const token = localStorage.getItem('token'); if(token) cfg.headers.Authorization = `Bearer ${token}`; return cfg })
export const registerUser = d => API.post('/auth/register', d)
export const loginUser = d => API.post('/auth/login', d)
export const getActivities = () => API.get('/activities')
export const addActivity = d => API.post('/activities', d)
export const seed = () => API.post('/seed')
export default API
