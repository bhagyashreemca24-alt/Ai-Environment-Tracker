import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { loginUser } from '../services/api'
export default function Login(){
  const nav = useNavigate();
  const [email,setEmail]=useState('');
  const [password,setPassword]=useState('');
  const [loading,setLoading]=useState(false);
  const submit=async(e)=>{
    e.preventDefault();
    if(!email || !password){ alert('Please fill all fields'); return; }
    setLoading(true);
    try{
      const res = await loginUser({ email, password });
      localStorage.setItem('token', res.data.token);
      nav('/dashboard');
    }catch(e){ alert(e.response?.data?.message || 'Login failed') }
    setLoading(false);
  }
  return (
    <div className='container' style={{maxWidth:560}}>
      <div className='card'>
        <h2>Login</h2>
        <form onSubmit={submit}>
          <input className='input' placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} />
          <input className='input' placeholder='Password' type='password' value={password} onChange={e=>setPassword(e.target.value)} />
          <div style={{display:'flex',gap:8,marginTop:8}}>
            <button className='btn btn-cta' type='submit' disabled={loading}>{loading? '...' : 'Login'}</button>
            <Link to='/reset-password' className='btn btn-primary'>Forgot password</Link>
          </div>
        </form>
      </div>
    </div>
  )
}
