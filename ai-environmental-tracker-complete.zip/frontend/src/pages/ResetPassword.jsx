import { useState } from 'react'
import axios from 'axios'
export default function ResetPassword(){
  const [email,setEmail]=useState('');
  const [token,setToken]=useState('');
  const [password,setPassword]=useState('');
  const send=async()=>{
    if(!email) return alert('Enter email');
    try{
      const res = await axios.post('http://localhost:5000/api/auth/forgot',{ email });
      alert(res.data.message + (res.data.token? ' - demo token: '+res.data.token : ''));
    }catch(e){ alert('Error sending') }
  }
  const reset=async()=>{
    if(!token||!password) return alert('Enter token and new password');
    try{
      const res = await axios.post('http://localhost:5000/api/auth/reset', { token, password });
      alert(res.data.message);
    }catch(e){ alert('Error resetting') }
  }
  return (
    <div className='container' style={{maxWidth:720}}>
      <div className='card'>
        <h2>Forgot password</h2>
        <p>Enter your email to receive a reset token (demo returns token directly if mail not configured).</p>
        <input className='input' placeholder='Email' value={email} onChange={e=>setEmail(e.target.value)} />
        <button className='btn btn-primary' onClick={send}>Send reset token</button>
        <hr />
        <h3>Reset (use token)</h3>
        <input className='input' placeholder='Token' value={token} onChange={e=>setToken(e.target.value)} />
        <input className='input' placeholder='New password' value={password} onChange={e=>setPassword(e.target.value)} />
        <button className='btn btn-cta' onClick={reset}>Reset password</button>
      </div>
    </div>
  )
}
