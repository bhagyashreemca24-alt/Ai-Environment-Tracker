import { useState } from 'react'
import { addActivity } from '../services/api'
import { useNavigate } from 'react-router-dom'
export default function AddActivity(){
  const nav = useNavigate();
  const [f,setF]=useState({ name:'', category:'', carbon:0 });
  const submit=async()=>{ try{ await addActivity(f); alert('Added'); nav('/dashboard') }catch(e){ alert('Error') } }
  return (
    <div className='container' style={{maxWidth:720}}>
      <div className='card'>
        <h2>Add Activity</h2>
        <input className='input' placeholder='Name' onChange={e=>setF({...f,name:e.target.value})} />
        <input className='input' placeholder='Category' onChange={e=>setF({...f,category:e.target.value})} />
        <input className='input' placeholder='Carbon (kg)' type='number' onChange={e=>setF({...f,carbon: Number(e.target.value)})} />
        <div style={{marginTop:8}}><button className='btn btn-cta' onClick={submit}>Save</button></div>
      </div>
    </div>
  )
}
