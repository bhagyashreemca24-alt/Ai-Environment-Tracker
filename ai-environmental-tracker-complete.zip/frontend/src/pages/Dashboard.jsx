import { useEffect, useState } from 'react'
import { getActivities, seed } from '../services/api'
import { Link } from 'react-router-dom'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'
export default function Dashboard(){
  const [list,setList]=useState([])
  useEffect(()=>{ load() },[])
  const load=async()=>{ try{ const r = await getActivities(); setList(r.data) }catch(e){ console.error(e) } }
  const doSeed=async()=>{ await seed(); await load(); alert('Seeded') }
  const chartData = list.slice(0,10).map((a,i)=>({ name: a.name || `A${i+1}`, co2: a.carbon || 0 }))
  return (
    <div className='container'>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <h2>Dashboard</h2>
        <div><button className='btn btn-primary' onClick={doSeed}>Seed Demo</button></div>
      </div>
      <div className='grid' style={{gridTemplateColumns:'1fr 320px',gap:18}}>
        <div>
          <div className='card'>
            <h3>CO₂ trend (recent)</h3>
            <div style={{width:'100%',height:220}}>
              <ResponsiveContainer>
                <LineChart data={chartData}>
                  <XAxis dataKey='name' />
                  <YAxis />
                  <Tooltip />
                  <Line type='monotone' dataKey='co2' stroke='#10b981' />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className='card'>
            <h3>Recent Activities</h3>
            <table className='table'>
              <thead><tr><th>Name</th><th>Category</th><th>CO₂</th></tr></thead>
              <tbody>
                {list.map(a=> <tr key={a._id}><td>{a.name}</td><td>{a.category}</td><td>{a.carbon}</td></tr>)}
              </tbody>
            </table>
          </div>
        </div>
        <div>
          <div className='card'>
            <h3>Summary</h3>
            <p>Total activities: {list.length}</p>
            <p>Estimated CO₂: {list.reduce((s,i)=>s+(i.carbon||0),0)}</p>
          </div>
          <div className='card'>
            <h3>AI Tips</h3>
            <ul>{list.slice(0,4).map(a=> <li key={a._id}><strong>{a.name}:</strong> {a.aiAnalysis?.slice(0,120)}</li>)}</ul>
          </div>
        </div>
      </div>
    </div>
  )
}
