import { useState } from 'react'
import { registerUser } from '../services/api'
import { useNavigate } from 'react-router-dom'
export default function Register(){
  const nav = useNavigate();
  const [form,setForm]=useState({ name:'', email:'', password:'' });
  const submit=async(e)=>{
    e.preventDefault();
    if(!form.name||!form.email||!form.password){ alert('Fill all fields'); return; }
    if(form.password.length < 6){ alert('Password must be at least 6 chars'); return; }
    try{ await registerUser(form); alert('Registered'); nav('/login'); }catch(e){ alert(e.response?.data?.message || 'Error') }
  }
  return (
    <div className='container' style={{maxWidth:560}}>
      <div className='card'>
        <h2>Create account</h2>
        <form onSubmit={submit}>
          <input className='input' placeholder='Name' onChange={e=>setForm({...form,name:e.target.value})} />
          <input className='input' placeholder='Email' onChange={e=>setForm({...form,email:e.target.value})} />
          <input className='input' placeholder='Password' type='password' onChange={e=>setForm({...form,password:e.target.value})} />
          <div style={{marginTop:8}}><button className='btn btn-cta' type='submit'>Create account</button></div>
        </form>
      </div>
    </div>
  )
}
