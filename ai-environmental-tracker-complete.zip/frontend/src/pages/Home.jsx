import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
export default function Home(){
  return (
    <div>
      <header className='hero'>
        <div className='container hero-inner'>
          <div className='hero-left'>
            <motion.h1 initial={{ y: 12, opacity:0 }} animate={{ y:0, opacity:1 }}>Track Your Environmental Impact</motion.h1>
            <p>Monitor activities, get AI tips, and reduce your carbon footprint.</p>
            <div style={{marginTop:18}}>
              <Link to='/register' className='btn btn-cta'>Get Started</Link>
            </div>
          </div>
          <div className='hero-right'>
            <div className='card stat-card'>
              <div className='stat-icon'>🍃</div>
              <div>
                <div className='stat-label'>Total Emissions</div>
                <div className='stat-value'>1234 kg</div>
              </div>
            </div>
          </div>
        </div>
      </header>
      <section className='container features'>
        <div className='feature card'>
          <div className='feature-icon'>🍃</div>
          <h3>Track Activities</h3>
          <p>Log daily actions and view emissions.</p>
        </div>
        <div className='feature card'>
          <div className='feature-icon'>📊</div>
          <h3>Dashboard</h3>
          <p>Charts and summaries to measure progress.</p>
        </div>
        <div className='feature card'>
          <div className='feature-icon'>🤖</div>
          <h3>AI Analysis</h3>
          <p>AI suggests low-impact alternatives.</p>
        </div>
      </section>
    </div>
  )
}
