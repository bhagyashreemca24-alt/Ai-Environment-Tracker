import { Link, useNavigate } from 'react-router-dom'
export default function Navbar(){
  const nav = useNavigate();
  const logout = ()=>{ localStorage.removeItem('token'); nav('/login'); }
  return (
    <nav className='navbar'>
      <div className='container nav-inner'>
        <Link to='/' className='brand'>🌿 AI Environmental Tracker</Link>
        <div className='nav-actions'>
          <Link to='/'>Home</Link>
          <Link to='/dashboard'>Dashboard</Link>
          <Link to='/add'>Add</Link>
          <button className='btn btn-primary' onClick={logout}>Logout</button>
        </div>
      </div>
    </nav>
  )
}
